document.addEventListener('DOMContentLoaded', () => {
    const slider = document.getElementById('volumeSlider');
    const label = document.getElementById('volumeLabel');
    const resetButton = document.getElementById('resetButton');
  
    // Load saved volume from localStorage
    chrome.storage.local.get(['youtubeVolume'], (result) => {
      const savedVolume = result.youtubeVolume || 100;
      slider.value = savedVolume;
      label.textContent = `${savedVolume}%`;
    });
  
    const updateVolume = (volume) => {
      label.textContent = `${volume}%`;
      chrome.storage.local.set({ youtubeVolume: volume });
  
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: setVolume,
          args: [volume]
        });
      });
    };
  
    slider.addEventListener('input', () => {
      const volume = slider.value;
      updateVolume(volume);
    });
  
    resetButton.addEventListener('click', () => {
      const resetVolume = 100;
      slider.value = resetVolume;
      updateVolume(resetVolume);
    });
  });
  
  function setVolume(volume) {
    let audioContext = window.audioContext || new AudioContext();
    window.audioContext = audioContext;
  
    const video = document.querySelector("video");
    if (video) {
      let gainNode = window.gainNode || audioContext.createGain();
      window.gainNode = gainNode;
  
      if (!video.audioSource) {
        const source = audioContext.createMediaElementSource(video);
        source.connect(gainNode);
        gainNode.connect(audioContext.destination);
        video.audioSource = source;
      }
  
      gainNode.gain.value = volume / 100;
    }
  }
  