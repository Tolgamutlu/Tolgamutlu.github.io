chrome.runtime.onInstalled.addListener(() => {
    console.log("YouTube Volume Master installed.");
  });
  