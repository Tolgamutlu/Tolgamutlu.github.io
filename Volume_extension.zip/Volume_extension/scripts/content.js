chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setVolume") {
      setVolume(request.volume);
      sendResponse({status: 'success'});
    }
  });
  
  function setVolume(volume) {
    let audioContext = window.audioContext || new AudioContext();
    window.audioContext = audioContext;
  
    const video = document.querySelector("video");
    if (video) {
      let gainNode = window.gainNode || audioContext.createGain();
      window.gainNode = gainNode;
  
      if (!video.audioSource) {
        const source = audioContext.createMediaElementSource(video);
        source.connect(gainNode);
        gainNode.connect(audioContext.destination);
        video.audioSource = source;
      }
  
      gainNode.gain.value = volume / 100;
    }
  }
  